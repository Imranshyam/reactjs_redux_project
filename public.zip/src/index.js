import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'
function Layout()
{
  return(
   <App />
  )
}
ReactDOM.render(<Layout/>,document.getElementById('root'));
