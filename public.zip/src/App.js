
import React, {useState} from 'react'
const App =()=>{
  const [email,setemail] = useState('');
  const [password,setpassword] = useState('');

  const emailonChange =(e)=>{
    console.log(e.target.value)
    setemail(e.target.value)
  }
  const passwordonChange =(e)=>{
 //   console.log(email:email,password:e.target.value)
 console.log(e.target.value)
    setpassword(e.target.value)
  }
  // const retonChange =(e)=>{
  //   console.log(e.target.value)
  
  const  myClick=(e)=>{
    e.preventDefault();
    alert("login successfully")
  }
  return(
    <form>
      <div class="row">
      <div class="col-md-8 offset-md-2">
        <h2 style={{color:"blue",textAlign:"center"}}>Login</h2>
      
      </div>

  <div class="col-md-8 offset-md-2">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" onChange={emailonChange} aria-describedby="emailHelp"/>
  
  </div>

  <div class="col-md-8 offset-md-2">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" onChange={passwordonChange}  />

  <br></br>
  <button onClick={myClick}  type="submit" value="login" id="navigation" class="btn btn-primary">Login</button>
  </div>
  </div>
 
</form>
  )
 
  }


export default App;





























